# PHISING-GAME
Generate phising attack game online
# Fiture
* Clash of clans
* Mobile Legends
# Termux
```
$ apt install python git php
$ pip install colorama
$ git clone https://github.com/aslanz-id/phising-game
$ cd phising-game
$ python phising.py
```
# Linux
```
$ sudo apt install git python3 php
$ sudo pip3 install colorama
$ git clone https://github.com/aslanz-id/phising-game
$ cd phising-game
$ python3 phising.py
```

# Windows
* Download python3: <a href="https://www.python.org/downloads/">click hare</a>
* Download script: <a href="https://github.com/aslanz-id/phising-game">click hare</a>
```
$ pip3 install colorama
$ phising.py
```
# Screenshot
<img src="https://l.top4top.io/p_1692ejhpb0.jpg">

# Support me
* Instagram: <a href="https://instagram.com/aslanz17">hare</a>
* Youtube: <a href="https://www.youtube.com/channel/UCCCNt7VP-EorlaGiKTpE4dQ?view_as=subscriber">hare</a>
* Twitter: <a href="https://twitter.com/Aslanzid">hare</a>


